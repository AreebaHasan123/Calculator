#include "Parent_Command.h"

int Parent_Command::execute(void)
{
	int n1;
	return n1;
}
